<!DOCTYPE html>
<html lang="es">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>LUDIBA GROUP - OpenSource Hosting</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Font Awesome if you need it
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- <link rel="stylesheet" href="https://unpkg.com/tailwindcss/dist/tailwind.min.css"> -->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/estilos-min.css">

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700" rel="stylesheet">

  <!-- Define your gradient here - use online tools to find a gradient matching your branding-->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/gradiente.css">

  <!-- Menú efecto drop -->
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/menu-drop.css">
  
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/recuadro.css">
  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/boton.css">

</head>